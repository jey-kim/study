#!/bin/bash

# Step 1: Copy InSAR data to the work directory

################################################
# *.mat files : (Murray et al., 2021 JGR)      #
#    --> Processed InSAR velocity data         #
#    -->> was provided by Kyle Murray.         #
#    -->>> Groundwater signal in California    #
# spline_fit_ref.out : (Bill's model)          #
#    --> Interpolated GPS horizontal field     #
#    -->> in Pacific reference frame.          #
#    -->>> This model was inferred from        #
#    -->>>> UCERF3 GPS consensus velocity.     #
################################################

# Step 2: Resample InSAR data and perform interpolation ?
sh Proj4_sample_InSAR_data_10132021.sh


# Step 3: Resample UCERF3 boundary condition velocity data.
#         The insar data has a reference point at (-116.528; 33.908; coherent pixel as a ref point)
sh Proj4_sample_BC_data_10132021.sh


# Step 4: Obtain basis functions : 
#         Force Balance equations inside & boundary basis function (from 3 rotations :x,y,and z)
sh Proj4_generate_basis_functions_11062021.sh

# Step 5: Invert them. 
#         Weighting factor for InSAR will be changed from 1 to 8.
#         An weighting factor will be inversely taken by the algorithm (e.g., 8 => 1/8)
sh Proj4_inversion_10132021.sh 


#!/bin/bash

## GENERATE xrot, yrot, zrot for the BASIS FUNCTIONS pertaining to BC velocity



## STEP 1. 
##input : geometry_kin.dat
##outputs: boundary_order.dat & coordinates.dat 

gfortran make_geometry_kin.f
./a.out
#cp geometry.dat geometry_kin.dat
gfortran Proj4_boundary_order_10302021.f
./a.out



## STEP 2. 
##inputs : null.dat & boundary_order.dat & coordinates.dat
##output : geometry_final.dat
rm null.dat
echo 0 > null.dat
echo 0 0 0 >> null.dat

gfortran make_sparse_boundary_geometry_fixed_corner.f -ffixed-line-length-none
./a.out

cp geometry_final.dat geometry.dat




## STEP 3. SPARSE programs
#make_sparse_geometry
#make_raw_spline_fit_dat
#cp spline_fit.dat raw_spline_fit.dat
#make_x_for_fit<<!
#0 0 0
#!




## STEP 4. 
##input : geometry_kin.dat
##output : boundary_rotations.dat 
gfortran Proj4_make_boundary_rotation_dat_11012021.f
./a.out



## STEP FINAL
gfortran make_boundary_rotations.f
./a.out

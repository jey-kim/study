#!/bin/bash

for i in 001 002  003  004  005  006  007  008  009  010  011  012  013  014  015  016  017  018  019  020  021  022  023  024  025  026  027  028  029  030  031  032  033  034  035  036  037  038  039  040  041  042  043  044  045  046  047  048  049  050  051  052  053  054  055  056  057  058  059  060  061  062  063  064  065  066 067  068  069  070  071  072  073  074  075  076  077  078  079  080  081  082  083  084  085  086  087  088  089  090  091  092  093  094  095  096  097

do



cp xrot"$i".dat rot.dat

input_spline_rotations

sparse_fit <<!
N
Y
N
!


sparse_average_strain <<!
N
Y
Y
!
cp average_strain.out "$i"_100.out

#echo running.....sparse_velocity
#sparse_velocity <<end
#Y
#0 0 0
#end
#cp velocity.out v{$i}_100.out


cp yrot"$i".dat rot.dat
input_spline_rotations

sparse_fit <<!
N
Y
N
!

sparse_average_strain <<!
N
Y
Y
!

cp average_strain.out "$i"_010.out

#echo running.....sparse_velocity
#sparse_velocity <<end
#Y
#0 0 0
#end
#cp velocity.out v{$i}_010.out

cp zrot"$i".dat rot.dat

input_spline_rotations

sparse_fit <<!
N
Y
N
!


sparse_average_strain <<!
N
Y
Y
!

cp average_strain.out "$i"_001.out

#echo running.....sparse_velocity
#sparse_velocity <<end
#Y
#0 0 0
#end
#cp velocity.out v{$i}_001.out

done



#I made boundary_order.dat. The number on the first row has been calculated by sumbtracting 1 from the total number of points on the boundary. Because the last point or the biggest number on the boundary is the fixed point which has the highest rotation value. So for the coordinates in geometry_final.dat all the order numbers are off by 1. e.g. instead of 3 for that coordinate on geometry_final.dat we see 4. The first column is the order numbers. The second one is the Y coordinates. The third one is the X coordinates.

#Run
gfortran make_boundary_order_dat.f
./a.out

#run
gfortran make_coordinates_dat.f
./a.out

#I made coordinates.dat file. No. of lat, No. of long, No. of flags, No. of plates.
#I made a null.dat file.

#touch null.dat
#0
#0 0 0


make_sparse_boundary_geometry
cp geometry_final.dat geometry.dat
make_sparse_geometry

#I opened up geometry.out to figure out what the rotation number is for each point. 

make_raw_spline_fit_dat

#I opened up spline_fit.dat to figure out what the total rotation number is.

cp spline_fit.dat raw_spline_fit.dat

make_x_for_fit<<!
0 0 0
!

#I made boundary_rotation.dat file. the first number is the total number of rotations. The second one is the total number of points around the boundary. The third one is the total number of hinge poins around the boundary. The firs column includes the order numbers. The second column includes (total number of rotations for fixed point - number of rotations for each hinge pont).

#run
gfortran make_boundary_rotation_dat.f
./a.out

make_boundary_rotations

make_boundary_spline_fit_dat

#This code produces the boundary_spline_fit.dat. For the first row, the first term is x coordinate, the second one is y coordinate, the third one is total number of rotaions. The number on the second row has been produced by subtracting the total number of boundary points from the total number of rotations. The number on the third row stands for the total number of areas.


stress_boundary_basis_functions_loop.sh

#I compiled the input_spline_rotations code which is embedded inside the above loop.
 
prepare_midpoints

#make a file named : input_file_names

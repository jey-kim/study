#!/bin/bash

lon_min=$(awk '{if(NR==1) print $1}' map_config.txt)
lon_max=$(awk '{if(NR==2) print $1}' map_config.txt)
lat_min=$(awk '{if(NR==3) print $1}' map_config.txt)
lat_max=$(awk '{if(NR==4) print $1}' map_config.txt)

## Obtain the max and min values
##  Compute the step size between the values
##   "$1" = the variable passed 
##        = track name
minmax=`gmt minmax masked_losx_"$1".xyz | awk '{print $7}'`
IFS=/ read min_1 max_1 <<< "$minmax"
min=`echo ${min_1:1}`
max=`echo ${max_1:0:8}`
min_2f=`printf '%.2f\n' $min`
max_2f=`printf '%.2f\n' $max`
step_size=$(awk -v min="$min_2f" -v max="$max_2f" 'BEGIN{print (max-min)/8}')
step_size_2f=`printf '%.2f\n' $step_size`


input="masked_losx_"$1".xyz"
M="px_"$1".ps"
R="-R$lon_min/$lon_max/$lat_min/$lat_max"
#R="-R-117/-116/33.2/34.1"
J="-Jm15"
CPT="pz.cpt"
B="-BneSW -Ba0.2f0.2"
#T="-T-0.71/-0.64/0.01"
T="-T"$min_2f"/"$max_2f"/"$step_size_2f""

gmt makecpt -Cgray $T -Z > $CPT
gmt psbasemap $R  $J  $B -V -Y2.0i -P -K > $M
gmt blockmean $input $R -I0.3m -V > px.dat
gmt surface px.dat -Gpx.grd -I0.3m $R -T0.2
gmt grdimage px.grd -C$CPT $R $J -V -O -K >>$M

#gmt psxy $input $R $J -Sc0.2 -C$CPT -L -V -O -K >>$M
#gmt pscoast $J $R  $B -Na -W1.0 -Slightblue -Df -V -O -K >> $M
gmt psscale -C$CPT -Dx6.3i/0i+w5.9i/0.2i -By+l"Px" -L -O >>$M
gmt psconvert $M -Tg -A
rm $M $CPT px.dat px.grd

#!/usr/bin/env python
# coding: utf-8

# In[7]:


import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from scipy.stats import multivariate_normal
matplotlib.rc('xtick', labelsize=14) 
matplotlib.rc('ytick', labelsize=14)
gridsize_x = 20
gridsize_y = 20
def gaussian(mux,muy,varx,vary,covarx,covary,scalingfac):
    
    mu = np.array([mux,muy])
    sigma = np.array([[varx,covarx],[covary,vary]])
    
    rv = multivariate_normal(mean=mu, cov=sigma)
    
    x = np.arange(1,20)
    y = np.arange(1,20)
    
    xmin = min(x) - 1
    xmax = max(x) + 1
    ymin = min(y) - 1
    ymax = max(y) + 1
    #plt.xlim(xmin,xmax)
    #plt.ylim(ymin,ymax)
    grid_spacing = 1
    xx1, xx2 = np.meshgrid(np.arange(xmin, xmax, grid_spacing), np.arange(ymin, ymax, grid_spacing))
    grid = np.c_[xx1.ravel(), xx2.ravel()]
    Z = np.array([rv.pdf(pt) for pt in grid])
    Z=Z*scalingfac
    Z = Z.reshape(xx1.shape)
    #plt.pcolormesh(xx1, xx2, Z, cmap=plt.cm.PRGn)
    #plt.colorbar(label="", orientation="horizontal")
    return Z

no_of_gaussians = int(input("Number of Gaussians:"))

Z = np.zeros((gridsize_x,gridsize_y),dtype=float)

for i in range(no_of_gaussians):
    mux, muy, varx, vary, covarx, covary, scalingfac = [float(s) for s in input("enter mux, muy, varx, vary, covarx, covary, scaling factor for gaussian "+str(i+1)).split()]
     
    Z += gaussian(mux,muy,varx,vary,covarx,covary,scalingfac)


Z_reshaped = Z.reshape(400,1)

import io
file=io.open("spline_fit.dat",mode="r",encoding="utf-8")
columns=file.read().splitlines()
file.close()

for i in range(6,len(columns)-2,4):
        x=columns[i-1].split()[0]  # x is cell number of the grid in string type
        v=int(float(x)) #v is x in int type
        y=(np.array2string(Z_reshaped[v],precision=3))  #y is reshaped Z 's element in string format
        q=y[1:-1] # q has removed brackets from Z string
        columns[i]="  " + q + "  " + q + "  0.000E+00"
        #print(columns[i])

#f=open("spline_fit_vertical.dat",mode="x")
f=open("spline_fit_vertical.dat",mode="w")
for i in range(len(columns)):
    f.write(str(columns[i]))
    f.write('\n')
f.close()


# In[ ]:





#!/bin/sh


lon_min=$(awk '{if(NR==1) print $1}' map_config.txt)
lon_max=$(awk '{if(NR==2) print $1}' map_config.txt)
lat_min=$(awk '{if(NR==3) print $1}' map_config.txt)
lat_max=$(awk '{if(NR==4) print $1}' map_config.txt)



#for the map boundary 
lon_min2=$(awk -v val="$lon_min" 'BEGIN{print val - 0.05}')
lon_max2=$(awk -v val="$lon_max" 'BEGIN{print val + 0.05}')
lat_min2=$(awk -v val="$lat_min" 'BEGIN{print val - 0.05}')
lat_max2=$(awk -v val="$lat_max" 'BEGIN{print val + 0.05}')


S="-Se0.03/0.95/0"
M="GNSS_synthetic.ps"
J="-Jm12"
B="-BneSW -Ba0.2f0.2"
R_larger="-R$lon_min2/$lon_max2/$lat_min2/$lat_max2"
R="-R$lon_min/$lon_max/$lat_min/$lat_max"

input="GNSS_horizontal_synthetic.gmt"
input_vert="vel_vertical_scaled.gmt"
CPT="vert.cpt"
T="-T-20/20/5"


awk '{print $1,$2}' $input > stations.dat
gmt gmtset FORMAT_GEO_MAP D

gmt makecpt -Cjet $T -Z > $CPT

gmt blockmean $input_vert $R -I0.6m -V > vert.dat
gmt surface vert.dat -Gvert.grd -I0.3m $R -T0.2
#gmt grd2cpt vert.grd -Cjet -Z -L0/20 $T > $CPT

gmt psbasemap $R_larger  $J $B -K -V -Y2.0i -P > $M
gmt grdimage vert.grd -C$CPT $R_larger $J -V -O -K >>$M
gmt psxy fault.dat $R_larger $J -W0.2,black $B -O -K -V >>$M
gmt psxy san_andras_fault.dat $R_larger $J -W0.2,black -O -K -V >>$M

gmt psxy $R_larger $J -O -K -L -Wthin -V >>$M <<END
$lon_min $lat_max
$lon_max $lat_max
$lon_max $lat_min
$lon_min $lat_min
END

gmt pscoast -Slightblue $R_larger -Wthick $J -O -K -Df >>$M
gmt psxy stations.dat $R_larger $J -St0.4c -Gwhite -W1,black -O -K -V >>$M
gmt psvelo $input $R_larger -W0.1,black -Gred $S  -L $J -A0.06/0.1/0.1 -O -K  >>$M 



lon_min3=$(awk -v val="$lon_min" 'BEGIN{print val + 0.03}')
lat_min3=$(awk -v val="$lat_min" 'BEGIN{print val - 0.025}')
lon_min4=$(awk -v val="$lon_min" 'BEGIN{print val + 0.3}')

gmt psvelo $R_larger -W0.5 -Gred $S  -L $J -A0.05/0.08/0.07 -O -K >>$M <<END
$lon_min3 $lat_min3  20 0 0   0 0 0
END

gmt psscale -C$CPT -Dx5.6i/0i+w5.4i/0.2i -By+l"[mm/yr]" -L -O -K >>$M

gmt pstext  $R_larger $J -P -O -V >> $M <<END
$lon_min4 $lat_min3     12   0.0   0       6     20 mm/yr
END

gmt psconvert $M -Tg -A

#!/bin/bash

lon_min=$(awk '{if(NR==1) print $1}' map_config.txt)
lon_max=$(awk '{if(NR==2) print $1}' map_config.txt)
lat_min=$(awk '{if(NR==3) print $1}' map_config.txt)
lat_max=$(awk '{if(NR==4) print $1}' map_config.txt)

minmax=`gmt minmax dLOS_"$1"_synthetic.dat | awk '{print $7}'`
IFS=/ read min_1 max_1 <<< "$minmax"
min=`echo ${min_1:1}`
max=`echo ${max_1:0:8}`
min_2f=`printf '%.0f\n' $min`
max_2f=`printf '%.0f\n' $max`

step_size=$(awk -v min="$min_2f" -v max="$max_2f" 'BEGIN{print (max-min)/8}')
step_size_2f=`printf '%.0f\n' $step_size`
R="-R$lon_min/$lon_max/$lat_min/$lat_max"
input="dLOS_"$1"_synthetic.dat"
M="dLOS_"$1"_synthetic.ps"
J="-Jm15"
CPT="dLOS.cpt"
B="-BneSW -Ba0.2f0.2"
T="-T"$min_2f"/"$max_2f"/"$step_size_2f""

gmt makecpt -Cpanoply $T -Z > $CPT
gmt psbasemap $R  $J  $B -V -Y2.0i -P -K > $M

gmt blockmean $input $R -I0.6m -V > dLOS.dat
gmt surface dLOS.dat -GdLOS.grd -I0.6m $R -T0.2
#gmt grd2xyz dLOS.grd > resample.dat
#gmt surface resample.dat -GdLOS1.grd -I15s  -R -T0.2
#gmt grdcut @earth_relief_01s $R -Gtopo.grd
#gmt grd2xyz topo.grd > elev.dat
#gmt surface elev.dat -Gelev.grd -I15s  -R -T0.2
#gmt grdgradient elev.grd $R -A0/270 -Ggradients.nc -Ne0.6 -V

gmt grdimage dLOS.grd -C$CPT $R $J -V -O -K >> $M
gmt pscoast $J $R  $B -Na -W1.0 -Slightblue -Df -V -O -K >> $M
gmt psxy fault.dat $R $J -W0.2,black $B -O -K -V >>$M
gmt psxy san_andras_fault.dat $R $J -W0.2,black -O -K -V >>$M
gmt psscale -C$CPT -Dx6.2i/0i+w5.9i/0.2i -By+l"[mm/yr]" -L -E -O >>$M
gmt psconvert $M -Tg -A
rm $M $CPT dLOS.dat dLOS.grd

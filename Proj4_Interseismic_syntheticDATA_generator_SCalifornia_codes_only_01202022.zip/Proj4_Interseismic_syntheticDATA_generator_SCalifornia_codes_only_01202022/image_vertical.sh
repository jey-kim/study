#!/bin/bash



lon_min=$(awk '{if(NR==1) print $1}' map_config.txt)
lon_max=$(awk '{if(NR==2) print $1}' map_config.txt)
lat_min=$(awk '{if(NR==3) print $1}' map_config.txt)
lat_max=$(awk '{if(NR==4) print $1}' map_config.txt)



R="-R$lon_min/$lon_max/$lat_min/$lat_max"
input="vel_vertical.gmt"
M="vertical.ps"
J="-Jm15"
CPT="vert.cpt"
B="-BneSW -Ba0.2f0.2"
T="-T-40/40/10"

gmt makecpt -Chaxby $T -Z > $CPT
gmt psbasemap $R  $J  $B -V -Y2.0i -P -K > $M

gmt blockmean $input $R -I0.6m -V > vert.dat
gmt surface vert.dat -Gvert.grd -I1m $R -T0.2
gmt grdimage vert.grd -C$CPT $R $J -V -O -K >>$M

#gmt psxy $input $R $J -Sc0.2 -C$CPT -L -V -O -K >>$M
#gmt pscoast $J $R  $B -Na -W1.0 -Slightblue -Df -V -O -K >> $M
gmt psscale -C$CPT -Dx6.6i/0i+w5.9i/0.2i -By+l"[mm/yr]" -L -E -O >>$M
gmt psconvert $M -Tg -A
rm $M $CPT vert.dat vert.grd

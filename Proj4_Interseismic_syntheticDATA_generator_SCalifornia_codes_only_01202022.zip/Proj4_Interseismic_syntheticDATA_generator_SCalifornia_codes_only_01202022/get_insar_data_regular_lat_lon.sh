#!/bin/bash

lon_min=$(awk '{if(NR==1) print $1}' map_config.txt)
lon_max=$(awk '{if(NR==2) print $1}' map_config.txt)
lat_min=$(awk '{if(NR==3) print $1}' map_config.txt)
lat_max=$(awk '{if(NR==4) print $1}' map_config.txt)
R="-R$lon_min/$lon_max/$lat_min/$lat_max"
#"$1" AT
#"$2" DT
awk '{print $1,$2}' vel_vertical.gmt > lonlat.dat

gmt xyz2grd masked_losx_"$1".xyz -I0.6 $R -Glosx_"$1"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosx_"$1"_regular_lat_long.grd > losx_"$1"_regular_lat_long.dat

gmt xyz2grd masked_losy_"$1".xyz -I0.6 $R -Glosy_"$1"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosy_"$1"_regular_lat_long.grd > losy_"$1"_regular_lat_long.dat

gmt xyz2grd masked_losz_"$1".xyz -I0.6 $R -Glosz_"$1"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosz_"$1"_regular_lat_long.grd > losz_"$1"_regular_lat_long.dat

gmt xyz2grd masked_losx_"$2".xyz -I0.6 $R -Glosx_"$2"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosx_"$2"_regular_lat_long.grd > losx_"$2"_regular_lat_long.dat

gmt xyz2grd masked_losy_"$2".xyz -I0.6 $R -Glosy_"$2"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosy_"$2"_regular_lat_long.grd > losy_"$2"_regular_lat_long.dat

gmt xyz2grd masked_losz_"$2".xyz -I0.6 $R -Glosz_"$2"_regular_lat_long.grd
gmt grdtrack lonlat.dat -Glosz_"$2"_regular_lat_long.grd > losz_"$2"_regular_lat_long.dat
